var indexSectionsWithContent =
{
  0: "adpu",
  1: "a",
  2: "u",
  3: "p",
  4: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions"
};

