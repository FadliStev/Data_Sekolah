﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace UAS_PAW_D
{

    public class Administrasi
    {
        
        double[] nomorinduk = new double[100];
        string [] nama = new string[100]; 
        string [] kelas = new string[100];
        string [] alamat = new string[100];
        string [] jeniskelamin = new string[100];
        
        

        public void DataSekolah()
        {
            Console.WriteLine("[][][][][][][][][][][][][][][][][][][][][][][][][][][][]");
            Console.WriteLine("\tSelamat Datang Di SMP Negeri 12 Sragen");
            Console.WriteLine("[][][][][][][][][][][][][][][][][][][][][][][][][][][][]");
            int i, n = 0;
            Console.WriteLine("Berapa Banyak Siswa Yang Ingin Di Inputkan Datanya ? :");
            n = int.Parse(Console.ReadLine());
            for (i = 1; i<=n; i++)
            {
                Console.Write("Silahkan Masukkan Kelas Siswa (A / B / C / D) = ");
                kelas[i] = Convert.ToString(Console.ReadLine());
                Console.Write("Silahkan Masukkan Nama Siswa = ");
                nama[i] = Convert.ToString(Console.ReadLine());
                Console.Write("Silahkan Masukkan Nomor Induk Siswa = ");
                nomorinduk[i] = Convert.ToInt32(Console.ReadLine());
                Console.Write("Silahkan Masukkan Jenis Kelamin Siswa = ");
                jeniskelamin[i] = Convert.ToString(Console.ReadLine());
                Console.Write("Silahkan Masukkan Alamat Siswa = ");
                alamat[i] = Convert.ToString(Console.ReadLine());

            }


            Console.Clear();

            Console.WriteLine("****************************************");
            Console.WriteLine("\tSMP Negeri 12 Sragen");
            Console.WriteLine("****************************************");
            for (i = 1; i <= n; i++)
            {
                switch (kelas[i])
                {
                    case "A":
                        Console.WriteLine("Wali Kelas : Pak Joko");
                        break;
                    case "B":
                        Console.WriteLine("Wali Kelas : Pak Dwi");
                        break;
                    case "C":
                        Console.WriteLine("Wali Kelas : Ibu Sindy");
                        break;
                    case "D":
                        Console.WriteLine("Wali Kelas : Ibu Sinta");
                        break;
                    default:
                        break;
                }
                Console.WriteLine($"Kelas Siswa = \t{kelas[i]}" +
                    $"\nNama Siswa = \t{nama[i]}" +
                    $"\nNomor Induk Siswa = \t{nomorinduk[i]}" +
                    $"\nJenis Kelamin Siswa = \t{jeniskelamin[i]}" +
                    $"\nAlamat Siswa = \t{alamat[i]}");
                
            }
            try
            {
                string path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                StreamWriter sw = new StreamWriter("D:\\PAW 2\\UAS_PAW_D\\" + ".txt");
                sw.WriteLine("****************************************");
                sw.WriteLine("\tSMP Negeri 12 Sragen");
                sw.WriteLine("****************************************");
                for (i = 1; i <= n; i++)
                {
                    
                    switch (kelas[i])
                    {
                        case "A":
                            sw.WriteLine("Wali Kelas : Pak Joko");
                            break;
                        case "B":
                            sw.WriteLine("Wali Kelas : Pak Dwi");
                            break;
                        case "C":
                            sw.WriteLine("Wali Kelas : Ibu Sindy");
                            break;
                        case "D":
                            sw.WriteLine("Wali Kelas : Ibu Sinta");
                            break;
                        default:
                            break;
                    }
                                        
                    sw.WriteLine($"Kelas Siswa\t\t\t\t= {kelas[i]}");
                    sw.WriteLine($"Nama Siswa\t\t\t\t= {nama[i]} ");
                    sw.WriteLine($"Nomor Induk Siswa\t\t\t= {nomorinduk[i]}");
                    sw.WriteLine($"Jenis Kelamin Siswa\t\t= {jeniskelamin[i]}");
                    sw.WriteLine($"Alamat Siswa\t\t\t= {alamat[i]}");
                }
                sw.Close();
            }
            catch (Exception e)
            {

                Console.WriteLine("Exception : " + e.Message);
            }

            finally
            {
                Console.WriteLine("Data Telah Tersimpan");
            }

            Console.ReadKey();
        }

       

    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Administrasi ad = new Administrasi();

            ad.DataSekolah();

        }
    }
}
