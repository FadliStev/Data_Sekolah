var searchData=
[
  ['nama_0',['nama',['../class_u_a_s___p_a_w___d__2_1_1_cafe.html#a0d9ff66248917ad8eab18f2005110f4f',1,'UAS_PAW_D_2::Cafe']]],
  ['nasigoreng_1',['Nasigoreng',['../class_u_a_s___p_a_w___d__2_1_1_cafe.html#af5be98971d91cf55ecf3426b441c4679',1,'UAS_PAW_D_2::Cafe']]]
];
