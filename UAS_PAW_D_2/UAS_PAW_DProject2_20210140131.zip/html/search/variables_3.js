var searchData=
[
  ['namakasir_0',['NamaKasir',['../class_u_a_s___p_a_w___d__2_1_1_cafe.html#a8e0ea09c5e4ba23d3335007284406aab',1,'UAS_PAW_D_2::Cafe']]],
  ['namapelanggan_1',['NamaPelanggan',['../class_u_a_s___p_a_w___d__2_1_1_cafe.html#aa7c1541d14fb0d796255dbc445337196',1,'UAS_PAW_D_2::Cafe']]]
];
