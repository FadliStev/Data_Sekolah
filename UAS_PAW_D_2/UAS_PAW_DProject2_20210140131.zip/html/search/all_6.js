var searchData=
[
  ['miegoreng_0',['Miegoreng',['../class_u_a_s___p_a_w___d__2_1_1_cafe.html#a43ec5bb2b06228f4476acd9cdc1ce117',1,'UAS_PAW_D_2::Cafe']]]
];
